from django.conf import settings
from django.db import models

from teams.models import Team


# A meeting is something an organiser schedules, optionally tied to a
# team (e.g. a sprint planning session for the CI/CD team) and with a
# list of attendees who get invited.
class Meeting(models.Model):

    PLATFORM_CHOICES = [
        ('teams', 'Microsoft Teams'),
        ('zoom', 'Zoom'),
        ('google_meet', 'Google Meet'),
        ('in_person', 'In Person'),
        ('other', 'Other'),
    ]

    title = models.CharField(max_length=150)
    agenda = models.TextField(
        blank=True,
        help_text='What the meeting will cover. Optional but recommended.',
    )

    # Use the project's user model rather than auth.User directly so
    # this still works if anyone swaps in a custom user later on.
    organiser = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='organised_meetings',
    )
    team = models.ForeignKey(
        Team,
        on_delete=models.SET_NULL,
        related_name='meetings',
        null=True,
        blank=True,
        help_text='Optionally associate this meeting with a team.',
    )
    attendees = models.ManyToManyField(
        settings.AUTH_USER_MODEL,
        related_name='invited_meetings',
        blank=True,
    )

    # Stored as a single datetime; duration kept separate so we can
    # render "10:00 - 11:00" easily and check for clashes later.
    starts_at = models.DateTimeField()
    duration_minutes = models.PositiveIntegerField(
        default=30,
        help_text='Length of the meeting in minutes.',
    )

    platform = models.CharField(
        max_length=20,
        choices=PLATFORM_CHOICES,
        default='teams',
    )
    location = models.CharField(
        max_length=200,
        blank=True,
        help_text='Meeting link or physical room.',
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['starts_at']

    def __str__(self):
        return f'{self.title} ({self.starts_at:%d %b %Y %H:%M})'

    @property
    def ends_at(self):
        # Computed on the fly so duration changes don't need a save.
        from datetime import timedelta
        return self.starts_at + timedelta(minutes=self.duration_minutes)
