from django import forms
from django.utils import timezone

from .models import Meeting


class MeetingForm(forms.ModelForm):

    # Use HTML5 datetime-local input so the browser shows a nice picker
    # and the browser-side validation catches obvious mistakes.
    starts_at = forms.DateTimeField(
        widget=forms.DateTimeInput(
            attrs={
                'type': 'datetime-local',
                'class': 'form-control',
            },
            format='%Y-%m-%dT%H:%M',
        ),
        input_formats=['%Y-%m-%dT%H:%M', '%Y-%m-%d %H:%M:%S'],
    )

    class Meta:
        model = Meeting
        fields = [
            'title', 'agenda', 'team', 'starts_at',
            'duration_minutes', 'platform', 'location', 'attendees',
        ]
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'agenda': forms.Textarea(
                attrs={'class': 'form-control', 'rows': 4},
            ),
            'team': forms.Select(attrs={'class': 'form-select'}),
            'duration_minutes': forms.NumberInput(
                attrs={'class': 'form-control', 'min': 5, 'step': 5},
            ),
            'platform': forms.Select(attrs={'class': 'form-select'}),
            'location': forms.TextInput(attrs={'class': 'form-control'}),
            'attendees': forms.SelectMultiple(
                attrs={'class': 'form-select', 'size': 6},
            ),
        }

    def clean_starts_at(self):
        # Don't let users schedule a meeting in the past.
        starts_at = self.cleaned_data['starts_at']
        if starts_at < timezone.now():
            raise forms.ValidationError(
                'Meetings must be scheduled for a future date and time.'
            )
        return starts_at

    def clean_duration_minutes(self):
        duration = self.cleaned_data['duration_minutes']
        if duration < 5:
            raise forms.ValidationError('Meetings must be at least 5 minutes long.')
        if duration > 8 * 60:
            raise forms.ValidationError('Meetings cannot be longer than 8 hours.')
        return duration
