from django.contrib import admin

from .models import Meeting


@admin.register(Meeting)
class MeetingAdmin(admin.ModelAdmin):
    list_display = ('title', 'organiser', 'team', 'starts_at',
                    'duration_minutes', 'platform')
    list_filter = ('platform', 'team', 'starts_at')
    search_fields = ('title', 'agenda', 'organiser__username')
    filter_horizontal = ('attendees',)
    date_hierarchy = 'starts_at'
