import calendar
from datetime import date, datetime, time, timedelta

from django.contrib import messages as flash_messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone

from .forms import MeetingForm
from .models import Meeting


def _user_meeting_qs(user):
    # Meetings the user is either organising or invited to. The Schedule
    # page should only show stuff that's actually relevant to you.
    return (
        Meeting.objects
        .filter(Q(organiser=user) | Q(attendees=user))
        .select_related('team', 'organiser')
        .prefetch_related('attendees')
        .distinct()
    )


@login_required
def upcoming(request):
    # Default landing page - meetings from now onwards.
    now = timezone.now()
    qs = _user_meeting_qs(request.user).filter(starts_at__gte=now).order_by('starts_at')

    context = {
        'meetings': qs,
        'now': now,
        'current_view': 'upcoming',
    }
    return render(request, 'schedule/upcoming.html', context)


@login_required
def weekly(request):
    # Show the week that contains the date in the ?date=YYYY-MM-DD
    # query string, defaulting to today.
    target = _parse_date_arg(request.GET.get('date'))
    week_start = target - timedelta(days=target.weekday())  # Monday
    week_end = week_start + timedelta(days=7)

    qs = (
        _user_meeting_qs(request.user)
        .filter(starts_at__date__gte=week_start, starts_at__date__lt=week_end)
        .order_by('starts_at')
    )

    # Group meetings by day so the template can render one column per day.
    days = []
    for offset in range(7):
        day = week_start + timedelta(days=offset)
        day_meetings = [m for m in qs if m.starts_at.date() == day]
        days.append({
            'date': day,
            'meetings': day_meetings,
            'is_today': day == date.today(),
        })

    context = {
        'days': days,
        'week_start': week_start,
        'week_end': week_end - timedelta(days=1),
        'prev_week': (week_start - timedelta(days=7)).isoformat(),
        'next_week': (week_start + timedelta(days=7)).isoformat(),
        'today_iso': date.today().isoformat(),
        'current_view': 'weekly',
    }
    return render(request, 'schedule/weekly.html', context)


@login_required
def monthly(request):
    target = _parse_date_arg(request.GET.get('date'))
    year, month = target.year, target.month

    # Build a calendar grid (list of weeks, each week is a list of days).
    cal = calendar.Calendar(firstweekday=0)  # Monday-first
    weeks = cal.monthdatescalendar(year, month)

    # Pre-fetch every meeting in the month plus a buffer for grid days
    # that bleed into adjacent months.
    month_start = weeks[0][0]
    month_end = weeks[-1][-1] + timedelta(days=1)
    qs = (
        _user_meeting_qs(request.user)
        .filter(starts_at__date__gte=month_start, starts_at__date__lt=month_end)
        .order_by('starts_at')
    )

    # Bucket meetings by date for fast template lookup.
    meetings_by_date = {}
    for meeting in qs:
        meetings_by_date.setdefault(meeting.starts_at.date(), []).append(meeting)

    grid = []
    for week in weeks:
        row = []
        for day in week:
            row.append({
                'date': day,
                'in_month': day.month == month,
                'is_today': day == date.today(),
                'meetings': meetings_by_date.get(day, []),
            })
        grid.append(row)

    # Previous/next month navigation
    prev_month = (target.replace(day=1) - timedelta(days=1)).replace(day=1)
    if month == 12:
        next_month = date(year + 1, 1, 1)
    else:
        next_month = date(year, month + 1, 1)

    context = {
        'grid': grid,
        'month_label': target.strftime('%B %Y'),
        'prev_month_iso': prev_month.isoformat(),
        'next_month_iso': next_month.isoformat(),
        'today_iso': date.today().isoformat(),
        'current_view': 'monthly',
    }
    return render(request, 'schedule/monthly.html', context)


@login_required
def detail(request, meeting_id):
    meeting = get_object_or_404(Meeting, pk=meeting_id)

    # Only the organiser or someone on the attendee list should see
    # the details of a meeting.
    if not (meeting.organiser_id == request.user.id
            or meeting.attendees.filter(id=request.user.id).exists()):
        raise Http404()

    context = {
        'meeting': meeting,
        'is_organiser': meeting.organiser_id == request.user.id,
    }
    return render(request, 'schedule/detail.html', context)


@login_required
def create(request):
    if request.method == 'POST':
        form = MeetingForm(request.POST)
        if form.is_valid():
            meeting = form.save(commit=False)
            meeting.organiser = request.user
            meeting.save()
            form.save_m2m()  # save attendees
            flash_messages.success(
                request,
                f'Meeting "{meeting.title}" scheduled.',
            )
            return redirect(reverse('schedule:detail',
                                    args=[meeting.id]))
    else:
        form = MeetingForm()

    context = {
        'form': form,
        'current_view': 'create',
    }
    return render(request, 'schedule/create.html', context)


@login_required
def cancel(request, meeting_id):
    meeting = get_object_or_404(Meeting, pk=meeting_id)
    # Only the organiser can cancel.
    if meeting.organiser_id != request.user.id:
        raise Http404()
    if request.method == 'POST':
        meeting.delete()
        flash_messages.info(request, 'Meeting cancelled.')
        return redirect('schedule:upcoming')
    return render(request, 'schedule/cancel_confirm.html',
                  {'meeting': meeting})


# Helpers

def _parse_date_arg(value):
    # Defaults to today if the value is missing or unparseable.
    if not value:
        return date.today()
    try:
        return datetime.strptime(value, '%Y-%m-%d').date()
    except ValueError:
        return date.today()
