from django.urls import path

from . import views


app_name = 'schedule'

urlpatterns = [
    path('', views.upcoming, name='upcoming'),
    path('weekly/', views.weekly, name='weekly'),
    path('monthly/', views.monthly, name='monthly'),
    path('new/', views.create, name='create'),
    path('<int:meeting_id>/', views.detail, name='detail'),
    path('<int:meeting_id>/cancel/', views.cancel, name='cancel'),
]
