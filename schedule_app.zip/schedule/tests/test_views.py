from datetime import timedelta

from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .fixtures import create_sample_meetings, create_test_user
from schedule.models import Meeting


# Anonymous users should be redirected on every page.
class AnonymousAccessTests(TestCase):

    def test_upcoming_redirects(self):
        response = self.client.get(reverse('schedule:upcoming'))
        self.assertEqual(response.status_code, 302)

    def test_weekly_redirects(self):
        response = self.client.get(reverse('schedule:weekly'))
        self.assertEqual(response.status_code, 302)

    def test_monthly_redirects(self):
        response = self.client.get(reverse('schedule:monthly'))
        self.assertEqual(response.status_code, 302)

    def test_create_redirects(self):
        response = self.client.get(reverse('schedule:create'))
        self.assertEqual(response.status_code, 302)


class UpcomingViewTests(TestCase):

    def setUp(self):
        self.user, password = create_test_user()
        self.client.login(username=self.user.username, password=password)
        self.sample = create_sample_meetings(self.user)

    def test_upcoming_renders(self):
        response = self.client.get(reverse('schedule:upcoming'))
        self.assertEqual(response.status_code, 200)

    def test_upcoming_excludes_past_meetings(self):
        response = self.client.get(reverse('schedule:upcoming'))
        self.assertNotContains(response, 'Past Standup')

    def test_upcoming_includes_future_meetings(self):
        response = self.client.get(reverse('schedule:upcoming'))
        self.assertContains(response, 'Today Sprint Review')
        self.assertContains(response, 'Next Week Planning')
        self.assertContains(response, 'Next Month Review')

    def test_upcoming_only_shows_user_meetings(self):
        # Another user's meeting shouldn't leak into our view.
        other, _ = create_test_user(username='outsider')
        Meeting.objects.create(
            title='Private Meeting',
            organiser=other,
            starts_at=timezone.now() + timedelta(days=1),
        )
        response = self.client.get(reverse('schedule:upcoming'))
        self.assertNotContains(response, 'Private Meeting')


class WeeklyViewTests(TestCase):

    def setUp(self):
        self.user, password = create_test_user()
        self.client.login(username=self.user.username, password=password)
        create_sample_meetings(self.user)

    def test_weekly_renders(self):
        response = self.client.get(reverse('schedule:weekly'))
        self.assertEqual(response.status_code, 200)

    def test_weekly_with_date_arg(self):
        response = self.client.get(reverse('schedule:weekly'),
                                   {'date': '2026-05-04'})
        self.assertEqual(response.status_code, 200)

    def test_weekly_handles_invalid_date_arg(self):
        # Should default to today instead of crashing.
        response = self.client.get(reverse('schedule:weekly'),
                                   {'date': 'not-a-date'})
        self.assertEqual(response.status_code, 200)


class MonthlyViewTests(TestCase):

    def setUp(self):
        self.user, password = create_test_user()
        self.client.login(username=self.user.username, password=password)
        create_sample_meetings(self.user)

    def test_monthly_renders(self):
        response = self.client.get(reverse('schedule:monthly'))
        self.assertEqual(response.status_code, 200)

    def test_monthly_with_date_arg(self):
        response = self.client.get(reverse('schedule:monthly'),
                                   {'date': '2026-12-01'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'December 2026')


class CreateMeetingTests(TestCase):

    def setUp(self):
        self.user, password = create_test_user()
        self.client.login(username=self.user.username, password=password)

    def test_create_get_renders_form(self):
        response = self.client.get(reverse('schedule:create'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Schedule a meeting')

    def test_create_post_creates_meeting(self):
        future = timezone.now() + timedelta(days=2)
        response = self.client.post(reverse('schedule:create'), data={
            'title': 'API Sync',
            'agenda': 'Discuss API contracts',
            'team': '',
            'starts_at': future.strftime('%Y-%m-%dT%H:%M'),
            'duration_minutes': 45,
            'platform': 'zoom',
            'location': 'https://zoom.us/example',
        })
        self.assertEqual(Meeting.objects.count(), 1)
        meeting = Meeting.objects.first()
        self.assertEqual(meeting.title, 'API Sync')
        self.assertEqual(meeting.organiser, self.user)
        # Should redirect to the detail page on success
        self.assertRedirects(
            response,
            reverse('schedule:detail', args=[meeting.id]),
        )

    def test_create_post_in_past_fails(self):
        past = timezone.now() - timedelta(days=1)
        response = self.client.post(reverse('schedule:create'), data={
            'title': 'Time Machine',
            'starts_at': past.strftime('%Y-%m-%dT%H:%M'),
            'duration_minutes': 30,
            'platform': 'teams',
            'team': '',
        })
        self.assertEqual(response.status_code, 200)  # form re-renders
        self.assertEqual(Meeting.objects.count(), 0)


class DetailViewTests(TestCase):

    def setUp(self):
        self.organiser, password = create_test_user(username='organiser')
        self.client.login(username='organiser', password=password)
        self.sample = create_sample_meetings(self.organiser)

    def test_organiser_can_view_detail(self):
        meeting = self.sample['today']
        response = self.client.get(
            reverse('schedule:detail', args=[meeting.id])
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, meeting.title)

    def test_attendee_can_view_detail(self):
        meeting = self.sample['today']
        invitee = self.sample['invitee']
        invitee.set_password('X1234567!')
        invitee.save()
        self.client.login(username=invitee.username, password='X1234567!')
        response = self.client.get(
            reverse('schedule:detail', args=[meeting.id])
        )
        self.assertEqual(response.status_code, 200)

    def test_uninvolved_user_cannot_view_detail(self):
        outsider, _ = create_test_user(username='outsider')
        self.client.login(username='outsider', password='Strong-Pass-1!')
        meeting = self.sample['today']
        response = self.client.get(
            reverse('schedule:detail', args=[meeting.id])
        )
        self.assertEqual(response.status_code, 404)


class CancelMeetingTests(TestCase):

    def setUp(self):
        self.organiser, password = create_test_user(username='organiser')
        self.client.login(username='organiser', password=password)
        self.sample = create_sample_meetings(self.organiser)

    def test_organiser_can_cancel(self):
        meeting = self.sample['next_week']
        response = self.client.post(
            reverse('schedule:cancel', args=[meeting.id])
        )
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Meeting.objects.filter(id=meeting.id).exists())

    def test_non_organiser_cannot_cancel(self):
        outsider, password = create_test_user(username='outsider')
        self.client.login(username='outsider', password=password)
        meeting = self.sample['next_week']
        response = self.client.post(
            reverse('schedule:cancel', args=[meeting.id])
        )
        self.assertEqual(response.status_code, 404)
        self.assertTrue(Meeting.objects.filter(id=meeting.id).exists())
