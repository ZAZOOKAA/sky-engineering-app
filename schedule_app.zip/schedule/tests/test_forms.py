from datetime import timedelta

from django.test import TestCase
from django.utils import timezone

from .fixtures import create_test_user
from schedule.forms import MeetingForm


class MeetingFormValidationTests(TestCase):

    def setUp(self):
        self.user, _ = create_test_user()
        # Future timestamp the form should accept.
        self.future = timezone.now() + timedelta(days=2)

    def _base_data(self, **overrides):
        data = {
            'title': 'Planning Meeting',
            'agenda': 'Discuss Q3 goals',
            'team': '',
            'starts_at': self.future.strftime('%Y-%m-%dT%H:%M'),
            'duration_minutes': 30,
            'platform': 'teams',
            'location': '',
        }
        data.update(overrides)
        return data

    def test_form_is_valid_with_good_data(self):
        form = MeetingForm(data=self._base_data())
        self.assertTrue(form.is_valid(), msg=form.errors)

    def test_form_rejects_meeting_in_the_past(self):
        past = timezone.now() - timedelta(days=1)
        form = MeetingForm(data=self._base_data(
            starts_at=past.strftime('%Y-%m-%dT%H:%M'),
        ))
        self.assertFalse(form.is_valid())
        self.assertIn('starts_at', form.errors)

    def test_form_rejects_zero_duration(self):
        form = MeetingForm(data=self._base_data(duration_minutes=0))
        self.assertFalse(form.is_valid())

    def test_form_rejects_excessive_duration(self):
        # > 8 hours should fail
        form = MeetingForm(data=self._base_data(duration_minutes=600))
        self.assertFalse(form.is_valid())
        self.assertIn('duration_minutes', form.errors)

    def test_form_requires_title(self):
        form = MeetingForm(data=self._base_data(title=''))
        self.assertFalse(form.is_valid())
        self.assertIn('title', form.errors)
