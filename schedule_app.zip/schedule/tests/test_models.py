from datetime import timedelta

from django.test import TestCase
from django.utils import timezone

from .fixtures import create_test_user
from schedule.models import Meeting


class MeetingModelTests(TestCase):

    def setUp(self):
        self.user, _ = create_test_user()

    def test_str_returns_title_and_date(self):
        meeting = Meeting.objects.create(
            title='Sprint Review',
            organiser=self.user,
            starts_at=timezone.now() + timedelta(days=1),
            duration_minutes=60,
        )
        self.assertIn('Sprint Review', str(meeting))

    def test_ends_at_is_starts_plus_duration(self):
        start = timezone.now() + timedelta(days=1)
        meeting = Meeting.objects.create(
            title='Standup',
            organiser=self.user,
            starts_at=start,
            duration_minutes=15,
        )
        self.assertEqual(
            meeting.ends_at,
            start + timedelta(minutes=15),
        )

    def test_default_duration_is_30_minutes(self):
        meeting = Meeting.objects.create(
            title='Quick Chat',
            organiser=self.user,
            starts_at=timezone.now() + timedelta(days=1),
        )
        self.assertEqual(meeting.duration_minutes, 30)

    def test_default_platform_is_teams(self):
        meeting = Meeting.objects.create(
            title='Test',
            organiser=self.user,
            starts_at=timezone.now() + timedelta(days=1),
        )
        self.assertEqual(meeting.platform, 'teams')
