from datetime import timedelta

from django.contrib.auth import get_user_model
from django.utils import timezone

from organization.models import Department
from teams.models import Team

from schedule.models import Meeting


def create_test_user(username='scheduler', password='Strong-Pass-1!'):
    User = get_user_model()
    user = User.objects.create_user(
        username=username,
        password=password,
        email=f'{username}@example.com',
        first_name=username.title(),
        last_name='Tester',
    )
    return user, password


def create_sample_meetings(organiser):
    # Builds a small set of meetings spread across past, this week, and
    # next month so the various views have something to render.
    now = timezone.now()

    User = get_user_model()
    invitee = User.objects.create_user(
        username='invitee', password='X1234567!',
    )

    department = Department.objects.create(
        name='Test Dept',
        specialisation='Testing',
        leader=organiser,
    )
    team = Team.objects.create(
        name='Test Team',
        mission='Testing',
        department=department,
        manager=organiser,
    )

    # Past meeting (should NOT show in upcoming)
    past = Meeting.objects.create(
        title='Past Standup',
        organiser=organiser,
        team=team,
        starts_at=now - timedelta(days=2),
        duration_minutes=15,
        platform='teams',
    )
    past.attendees.add(invitee)

    # Upcoming meeting today
    today_meeting = Meeting.objects.create(
        title='Today Sprint Review',
        organiser=organiser,
        team=team,
        starts_at=now + timedelta(hours=3),
        duration_minutes=60,
        platform='zoom',
    )
    today_meeting.attendees.add(invitee)

    # Next week
    next_week = Meeting.objects.create(
        title='Next Week Planning',
        organiser=organiser,
        team=team,
        starts_at=now + timedelta(days=8),
        duration_minutes=45,
        platform='in_person',
    )

    # Next month
    next_month = Meeting.objects.create(
        title='Next Month Review',
        organiser=organiser,
        team=team,
        starts_at=now + timedelta(days=35),
        duration_minutes=30,
        platform='google_meet',
    )

    return {
        'invitee': invitee,
        'team': team,
        'past': past,
        'today': today_meeting,
        'next_week': next_week,
        'next_month': next_month,
    }
