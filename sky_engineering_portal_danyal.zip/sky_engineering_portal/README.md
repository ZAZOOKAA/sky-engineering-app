# Sky Engineering Portal — Reports Module

**5COSC021W Software Development Group Project — Coursework 2**
Individual element: Student 5 (Reports — PDF / Excel)

Author: Danyal [INSERT SURNAME] ([INSERT REGISTRATION NUMBER])
Group: [INSERT GROUP NAME]

## Quick start

```bash
# 1. Create a virtual environment and install dependencies
python -m venv venv
source venv/bin/activate         # (or venv\Scripts\activate on Windows)
pip install -r requirements.txt

# 2. Run database migrations
python manage.py migrate

# 3. Seed the database with sample data
python manage.py seed_data

# 4. Run the development server
python manage.py runserver
```

Open <http://127.0.0.1:8000/> in a browser. The reports landing page
will redirect you to log in.

## Default test credentials

The `seed_data` command creates a superuser:

- **Username:** `admin`
- **Password:** `Admin-Pass-1!`

## Running the test suite

```bash
python manage.py test reports
```

37 tests cover the queries, generators, views and authentication.

## Available reports

| Report | PDF | Excel |
|---|---|---|
| All Teams | `/reports/teams_summary/pdf/` | `/reports/teams_summary/xlsx/` |
| Teams Without Managers | `/reports/teams_without_managers/pdf/` | `/reports/teams_without_managers/xlsx/` |
| Department Summary | `/reports/department_summary/pdf/` | `/reports/department_summary/xlsx/` |

## Project structure

```
sky_engineering_portal/
├── manage.py
├── requirements.txt
├── sky_portal/             Django project settings
├── organisation/           Placeholder models (replaced on integration)
└── reports/                ← Individual element
    ├── branding.py         Sky colour palette, fonts
    ├── queries.py          Data layer - single point of integration
    ├── pdf_generator.py    BasePDFReport + 3 concrete reports
    ├── excel_generator.py  BaseExcelReport + 3 concrete reports
    ├── views.py            HTTP views (login required)
    ├── urls.py
    ├── templates/reports/  Sky-branded landing page
    └── tests/              37 tests (queries, generators, views)
```

## Notes for integration into the group project

The `organisation` app is a placeholder; in the group project, it
should be replaced by the team's shared models app. To integrate:

1. Copy the `reports/` folder into the group project.
2. Add `'reports'` to `INSTALLED_APPS` in the group's settings.
3. Add `path('reports/', include('reports.urls'))` to the group's
   root `urls.py`.
4. Update the imports in `reports/queries.py` to point at the group's
   actual models module.
