"""
Management command to seed the database with sample data.

Author: PLACEHOLDER (group integration: replace with the team's seed
script if there is one)

Run with:
    python manage.py seed_data

This populates a small but realistic Sky-style organisation so the
reports have something to display. Safe to run multiple times - it
clears existing rows first.
"""

from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model

from organisation.models import Department, Engineer, Team


class Command(BaseCommand):
    help = 'Populate the database with sample organisation data.'

    def handle(self, *args, **options):
        # Wipe existing data to keep this idempotent.
        Team.objects.all().delete()
        Engineer.objects.all().delete()
        Department.objects.all().delete()

        self.stdout.write('Creating departments...')
        platform = Department.objects.create(
            name='Platform Engineering',
            leader_name='Priya Patel',
            leader_email='priya.patel@example.com',
            specialisation='Cloud, observability, CI/CD',
        )
        streaming = Department.objects.create(
            name='Streaming',
            leader_name='Marcus Webb',
            leader_email='marcus.webb@example.com',
            specialisation='Video delivery, encoding, CDN',
        )
        identity = Department.objects.create(
            name='Identity & Access',
            leader_name='Lena Fischer',
            specialisation='Authentication, account systems, fraud',
        )

        self.stdout.write('Creating engineers...')
        managers = [
            Engineer.objects.create(full_name='Olivia Bennett',
                                    email='olivia.bennett@example.com',
                                    role='Engineering Manager'),
            Engineer.objects.create(full_name='Daniel Choi',
                                    email='daniel.choi@example.com',
                                    role='Engineering Manager'),
            Engineer.objects.create(full_name='Sara Hussain',
                                    email='sara.hussain@example.com',
                                    role='Engineering Manager'),
            Engineer.objects.create(full_name='Tom Reilly',
                                    email='tom.reilly@example.com',
                                    role='Engineering Manager'),
        ]
        engineers = [
            Engineer.objects.create(full_name=name, email=email)
            for name, email in [
                ('Aiko Tanaka', 'aiko.tanaka@example.com'),
                ('Ben Carter', 'ben.carter@example.com'),
                ('Chloe Müller', 'chloe.muller@example.com'),
                ('Diego Romero', 'diego.romero@example.com'),
                ('Esme Walker', 'esme.walker@example.com'),
                ('Faisal Ahmed', 'faisal.ahmed@example.com'),
                ('Grace Liu', 'grace.liu@example.com'),
                ('Henrik Olsen', 'henrik.olsen@example.com'),
                ('Isla Murphy', 'isla.murphy@example.com'),
                ('Jordan Reeves', 'jordan.reeves@example.com'),
                ('Kim Park', 'kim.park@example.com'),
                ('Lukas Weber', 'lukas.weber@example.com'),
                ('Maya Singh', 'maya.singh@example.com'),
                ('Noah Edwards', 'noah.edwards@example.com'),
                ('Omar Yilmaz', 'omar.yilmaz@example.com'),
            ]
        ]

        self.stdout.write('Creating teams...')

        def make_team(name, dept, manager, mems, contact, repo='', purpose=''):
            t = Team.objects.create(
                name=name,
                department=dept,
                manager=manager,
                contact_channel=contact,
                code_repository=repo,
                purpose=purpose,
            )
            t.members.set(mems)
            return t

        t1 = make_team(
            'Observability', platform, managers[0], engineers[0:5],
            '#observability',
            'https://example.com/repos/observability',
            'Logs, metrics, traces and dashboards across all Sky services.',
        )
        t2 = make_team(
            'CI/CD', platform, managers[1], engineers[5:9],
            '#ci-cd',
            'https://example.com/repos/cicd',
            'Build, test and deployment pipelines.',
        )
        t3 = make_team(
            'Cloud Foundation', platform, managers[0], engineers[9:13],
            '#cloud-foundation',
            'https://example.com/repos/cloud',
            'AWS landing zone, IAM, networking.',
        )
        t4 = make_team(
            'Encoding', streaming, managers[2], engineers[0:3] + engineers[8:10],
            '#encoding',
            'https://example.com/repos/encoding',
            'Video encoding pipeline.',
        )
        t5 = make_team(
            'Playback', streaming, None, engineers[3:8],
            '#playback', purpose='Client-side playback SDKs.',
        )
        t6 = make_team(
            'CDN', streaming, managers[3], engineers[10:15],
            '#cdn',
            'https://example.com/repos/cdn',
            'Content delivery network operations.',
        )
        t7 = make_team(
            'Auth Services', identity, managers[1], engineers[2:7],
            '#auth', purpose='OAuth, SSO, MFA.',
        )
        t8 = make_team(
            'Account Systems', identity, None, engineers[7:12],
            '#accounts',
            purpose='User profiles and account lifecycle.',
        )
        t9 = make_team(
            'Fraud Prevention', identity, managers[3], engineers[1:6],
            '#fraud', purpose='Detection of fraudulent activity.',
        )

        # Add a few dependencies
        t2.upstream_dependencies.set([t1])  # CI/CD depends on Observability
        t4.upstream_dependencies.set([t3])  # Encoding depends on Cloud Foundation
        t5.upstream_dependencies.set([t4, t6])  # Playback depends on Encoding & CDN
        t7.upstream_dependencies.set([t3])
        t8.upstream_dependencies.set([t7])

        # Default admin user for testing
        User = get_user_model()
        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser(
                'admin', 'admin@example.com', 'Admin-Pass-1!'
            )
            self.stdout.write(self.style.SUCCESS(
                'Created superuser: admin / Admin-Pass-1!'
            ))

        self.stdout.write(self.style.SUCCESS(
            f'Seeded {Department.objects.count()} departments, '
            f'{Team.objects.count()} teams, '
            f'{Engineer.objects.count()} engineers.'
        ))
