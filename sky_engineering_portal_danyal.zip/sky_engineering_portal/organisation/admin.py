"""Admin registration for placeholder organisation models."""

from django.contrib import admin

from .models import Department, Engineer, Team


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'leader_name', 'specialisation')
    search_fields = ('name', 'leader_name')


@admin.register(Engineer)
class EngineerAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'email', 'role')
    search_fields = ('full_name', 'email')


@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ('name', 'department', 'manager', 'member_count')
    list_filter = ('department',)
    search_fields = ('name', 'purpose')
    filter_horizontal = ('members', 'upstream_dependencies')
