"""App configuration for the organisation module (placeholder)."""

from django.apps import AppConfig


class OrganisationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'organisation'
    verbose_name = 'Organisation (placeholder)'
