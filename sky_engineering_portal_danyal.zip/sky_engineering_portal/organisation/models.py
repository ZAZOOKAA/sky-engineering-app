"""
Placeholder models representing the data structure from the brief.

Author: PLACEHOLDER - in the group project these models are owned by
        whichever team member is leading the database design.

These are stand-ins for the group's shared data model. They match the
fields specified in the coursework brief:
    - Department (name, leader, etc.)
    - Team (name, manager, department, members, dependencies, etc.)
    - Engineer (team members)

When integrating into the group project, delete this app entirely and
update reports.queries to import from the group's actual models module.
"""

from django.db import models


class Department(models.Model):
    """Represents an engineering department at Sky."""

    name = models.CharField(max_length=100, unique=True)
    leader_name = models.CharField(max_length=100, blank=True)
    leader_email = models.EmailField(blank=True)
    specialisation = models.CharField(max_length=200, blank=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class Engineer(models.Model):
    """An engineer who belongs to a team."""

    full_name = models.CharField(max_length=100)
    email = models.EmailField()
    role = models.CharField(max_length=80, default='Engineer')

    class Meta:
        ordering = ['full_name']

    def __str__(self):
        return self.full_name


class Team(models.Model):
    """An engineering team within a department.

    Represents a single entry from Sky's team registry. Each team can
    have upstream and downstream dependencies which are other teams.
    """

    name = models.CharField(max_length=100, unique=True)
    department = models.ForeignKey(
        Department,
        on_delete=models.CASCADE,
        related_name='teams',
    )
    # Manager is nullable because the brief specifically asks us to
    # produce a "teams without managers" report - this models that case.
    manager = models.ForeignKey(
        Engineer,
        on_delete=models.SET_NULL,
        related_name='managed_teams',
        null=True,
        blank=True,
    )
    members = models.ManyToManyField(
        Engineer,
        related_name='teams',
        blank=True,
    )
    purpose = models.TextField(blank=True)
    code_repository = models.URLField(blank=True)
    contact_channel = models.CharField(max_length=200, blank=True)

    # Self-referencing many-to-many for upstream/downstream dependencies.
    # Symmetrical=False so we can distinguish direction.
    upstream_dependencies = models.ManyToManyField(
        'self',
        symmetrical=False,
        related_name='downstream_dependencies',
        blank=True,
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['department__name', 'name']

    def __str__(self):
        return f'{self.name} ({self.department.name})'

    def member_count(self):
        return self.members.count()
