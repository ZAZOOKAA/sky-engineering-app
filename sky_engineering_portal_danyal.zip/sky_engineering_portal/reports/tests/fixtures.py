"""
Shared test fixtures.

Author: Danyal [INSERT SURNAME]
Module: 5COSC021W - CW2 Individual Element

A single helper that creates a small but representative organisation
hierarchy. Used by every test module to keep setup consistent.
"""

from django.contrib.auth import get_user_model

from organisation.models import Department, Engineer, Team


def create_test_user(username='reporter', password='Strong-Pass-1!'):
    """Return a logged-in test user."""
    User = get_user_model()
    user = User.objects.create_user(
        username=username,
        password=password,
        email=f'{username}@example.com',
    )
    return user, password


def create_sample_organisation():
    """Build a small but realistic organisation tree for tests.

    Returns a dict with the created entities for assertion convenience.
    """
    # Two departments
    platform = Department.objects.create(
        name='Platform Engineering',
        leader_name='A. Director',
        leader_email='a.director@example.com',
        specialisation='Cloud, observability, CI/CD',
    )
    streaming = Department.objects.create(
        name='Streaming',
        leader_name='B. Director',
        specialisation='Video delivery, encoding',
    )

    # Engineers
    alice = Engineer.objects.create(
        full_name='Alice Khan', email='alice@example.com', role='Manager',
    )
    bob = Engineer.objects.create(
        full_name='Bob Singh', email='bob@example.com',
    )
    carol = Engineer.objects.create(
        full_name='Carol Lee', email='carol@example.com',
    )

    # Three teams: two with a manager, one without
    observability = Team.objects.create(
        name='Observability',
        department=platform,
        manager=alice,
        contact_channel='#observability',
        code_repository='https://example.com/repos/observability',
    )
    observability.members.add(alice, bob, carol)

    ci_cd = Team.objects.create(
        name='CI/CD',
        department=platform,
        manager=alice,
        contact_channel='#ci-cd',
    )
    ci_cd.members.add(bob)

    encoding = Team.objects.create(
        name='Encoding',
        department=streaming,
        manager=None,  # deliberately unmanaged for the gap report
        contact_channel='#encoding',
    )
    encoding.members.add(carol)

    return {
        'platform': platform,
        'streaming': streaming,
        'engineers': [alice, bob, carol],
        'teams': [observability, ci_cd, encoding],
    }
