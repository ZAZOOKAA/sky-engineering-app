"""
Tests for the PDF and Excel generators.

Author: Danyal [INSERT SURNAME]
Module: 5COSC021W - CW2 Individual Element

These tests verify that the generators produce well-formed output and
that the data they contain matches what queries.py returns.

Test plan covered:
    G-01  Every PDF starts with the %PDF magic header
    G-02  Every Excel file starts with the ZIP magic header (xlsx is a zip)
    G-03  Empty database produces a valid (non-empty) file with a fallback message
    G-04  Generated PDFs contain the expected team/department names
    G-05  Generated Excel files contain the expected team/department names
"""

import io
import zipfile

from django.test import TestCase
from openpyxl import load_workbook
from pypdf import PdfReader

from reports import excel_generator, pdf_generator
from .fixtures import create_sample_organisation


def extract_pdf_text(pdf_bytes: bytes) -> str:
    """Extract all readable text from a PDF byte string.

    PDF text streams are usually compressed, so we cannot rely on a
    bytes-in check. pypdf decodes the streams and returns the text.
    """
    reader = PdfReader(io.BytesIO(pdf_bytes))
    return '\n'.join(page.extract_text() or '' for page in reader.pages)


# ---------------------------------------------------------------------
# PDF generator tests
# ---------------------------------------------------------------------

class PDFGeneratorBoundaryTests(TestCase):
    """G-01, G-03 - empty database boundary case."""

    def test_teams_summary_pdf_is_valid_when_empty(self):
        pdf_bytes = pdf_generator.TeamsSummaryReport().render()
        self.assertTrue(pdf_bytes.startswith(b'%PDF'))
        self.assertGreater(len(pdf_bytes), 1000)

    def test_unmanaged_pdf_is_valid_when_empty(self):
        pdf_bytes = pdf_generator.TeamsWithoutManagersReport().render()
        self.assertTrue(pdf_bytes.startswith(b'%PDF'))
        self.assertGreater(len(pdf_bytes), 1000)

    def test_department_summary_pdf_is_valid_when_empty(self):
        pdf_bytes = pdf_generator.DepartmentSummaryReport().render()
        self.assertTrue(pdf_bytes.startswith(b'%PDF'))
        self.assertGreater(len(pdf_bytes), 1000)


class PDFGeneratorContentTests(TestCase):
    """G-01, G-04 - happy-path PDF content checks."""

    def setUp(self):
        create_sample_organisation()

    def test_teams_summary_pdf_starts_with_magic(self):
        pdf_bytes = pdf_generator.TeamsSummaryReport().render()
        self.assertTrue(pdf_bytes.startswith(b'%PDF'))

    def test_teams_summary_pdf_contains_team_names(self):
        pdf_bytes = pdf_generator.TeamsSummaryReport().render()
        text = extract_pdf_text(pdf_bytes)
        self.assertIn('Observability', text)
        self.assertIn('CI/CD', text)
        self.assertIn('Encoding', text)

    def test_unmanaged_pdf_only_lists_unmanaged_team(self):
        pdf_bytes = pdf_generator.TeamsWithoutManagersReport().render()
        text = extract_pdf_text(pdf_bytes)
        self.assertIn('Encoding', text)
        self.assertIn('Teams Without Managers', text)
        # Teams that have a manager should not appear in the table.
        self.assertNotIn('Observability', text)
        self.assertNotIn('CI/CD', text)

    def test_department_pdf_lists_both_departments(self):
        pdf_bytes = pdf_generator.DepartmentSummaryReport().render()
        text = extract_pdf_text(pdf_bytes)
        self.assertIn('Platform Engineering', text)
        self.assertIn('Streaming', text)


# ---------------------------------------------------------------------
# Excel generator tests
# ---------------------------------------------------------------------

class ExcelGeneratorBoundaryTests(TestCase):
    """G-02, G-03 - empty database boundary case."""

    def test_teams_summary_xlsx_is_valid_when_empty(self):
        xlsx_bytes = excel_generator.TeamsSummaryReport().render()
        # XLSX files are ZIP archives.
        self.assertTrue(zipfile.is_zipfile(io.BytesIO(xlsx_bytes)))

    def test_unmanaged_xlsx_is_valid_when_empty(self):
        xlsx_bytes = excel_generator.TeamsWithoutManagersReport().render()
        self.assertTrue(zipfile.is_zipfile(io.BytesIO(xlsx_bytes)))


class ExcelGeneratorContentTests(TestCase):
    """G-02, G-05 - happy-path Excel content checks."""

    def setUp(self):
        create_sample_organisation()

    def test_teams_summary_xlsx_contains_every_team(self):
        xlsx_bytes = excel_generator.TeamsSummaryReport().render()
        wb = load_workbook(io.BytesIO(xlsx_bytes))
        ws = wb.active

        # Collect all string values from the sheet
        cells = [
            cell.value
            for row in ws.iter_rows()
            for cell in row
            if cell.value is not None
        ]
        joined = ' '.join(str(c) for c in cells)

        self.assertIn('Observability', joined)
        self.assertIn('CI/CD', joined)
        self.assertIn('Encoding', joined)

    def test_unmanaged_xlsx_lists_unmanaged_team(self):
        xlsx_bytes = excel_generator.TeamsWithoutManagersReport().render()
        wb = load_workbook(io.BytesIO(xlsx_bytes))
        ws = wb.active

        cells = [
            cell.value for row in ws.iter_rows()
            for cell in row if cell.value is not None
        ]
        joined = ' '.join(str(c) for c in cells)
        self.assertIn('Encoding', joined)

    def test_department_xlsx_lists_both_departments(self):
        xlsx_bytes = excel_generator.DepartmentSummaryReport().render()
        wb = load_workbook(io.BytesIO(xlsx_bytes))
        ws = wb.active

        cells = [
            cell.value for row in ws.iter_rows()
            for cell in row if cell.value is not None
        ]
        joined = ' '.join(str(c) for c in cells)
        self.assertIn('Platform Engineering', joined)
        self.assertIn('Streaming', joined)

    def test_department_xlsx_team_count_for_platform_is_correct(self):
        xlsx_bytes = excel_generator.DepartmentSummaryReport().render()
        wb = load_workbook(io.BytesIO(xlsx_bytes))
        ws = wb.active

        # Find the Platform Engineering row and check the team count column.
        for row in ws.iter_rows(values_only=True):
            if row and row[0] == 'Platform Engineering':
                # Columns: department, leader, specialisation, teams, unmanaged, engineers
                self.assertEqual(row[3], 2)
                return
        self.fail('Platform Engineering row was not found in the sheet.')
