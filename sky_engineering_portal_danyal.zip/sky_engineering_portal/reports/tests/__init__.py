"""Test suite for the reports app."""
