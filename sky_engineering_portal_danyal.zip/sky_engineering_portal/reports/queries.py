"""
Data queries used to build reports.

Author: Danyal [INSERT SURNAME]
Module: 5COSC021W - CW2 Individual Element

This module is the single point of contact between the reports app and
the rest of the project's data. Keeping all the ORM queries here means:

  1. When integrating with the group's actual models, only this file
     needs its imports updated - the generators and views never touch
     models directly.
  2. Tests can mock or replace these functions easily.
  3. If the schema evolves, only one place needs to change.

Each function returns a plain Python list of dicts so that the
generators (PDF/Excel) don't need to know anything about Django.
"""

from datetime import datetime

from django.db.models import Count, Q

from organisation.models import Department, Team


def teams_summary():
    """Return a list of every team with summary information.

    Used by the 'All Teams' report. Each row contains the team name,
    department, manager, member count and contact channel.
    """
    teams = (
        Team.objects
        .select_related('department', 'manager')
        .prefetch_related('members')
        .annotate(num_members=Count('members'))
        .order_by('department__name', 'name')
    )

    rows = []
    for team in teams:
        rows.append({
            'team': team.name,
            'department': team.department.name,
            'manager': team.manager.full_name if team.manager else '— Unassigned —',
            'members': team.num_members,
            'contact': team.contact_channel or 'N/A',
            'repository': team.code_repository or 'N/A',
        })
    return rows


def teams_without_managers():
    """Return teams that have no manager assigned.

    The brief specifically calls this report out by name. It is critical
    operational data - a team without a manager is a gap in accountability.
    """
    teams = (
        Team.objects
        .filter(manager__isnull=True)
        .select_related('department')
        .annotate(num_members=Count('members'))
        .order_by('department__name', 'name')
    )

    rows = []
    for team in teams:
        rows.append({
            'team': team.name,
            'department': team.department.name,
            'members': team.num_members,
            'contact': team.contact_channel or 'N/A',
            'created': team.created_at.strftime('%d %b %Y'),
        })
    return rows


def department_summary():
    """Return totals grouped by department.

    For each department, count the number of teams and the total
    headcount across those teams. Useful for senior leadership briefs.
    """
    departments = (
        Department.objects
        .annotate(
            num_teams=Count('teams', distinct=True),
            num_unmanaged=Count(
                'teams',
                filter=Q(teams__manager__isnull=True),
                distinct=True,
            ),
        )
        .order_by('name')
    )

    rows = []
    for dept in departments:
        # Sum members across all teams in this department.
        # Done in Python rather than the ORM to keep the query simple
        # and avoid double-counting engineers who belong to multiple teams.
        member_ids = set()
        for team in dept.teams.all():
            for member in team.members.all():
                member_ids.add(member.id)

        rows.append({
            'department': dept.name,
            'leader': dept.leader_name or '— Not set —',
            'specialisation': dept.specialisation or 'N/A',
            'num_teams': dept.num_teams,
            'unmanaged_teams': dept.num_unmanaged,
            'unique_engineers': len(member_ids),
        })
    return rows


def overall_totals():
    """Return a small dict of headline numbers for the cover page."""
    total_teams = Team.objects.count()
    total_unmanaged = Team.objects.filter(manager__isnull=True).count()
    total_departments = Department.objects.count()

    return {
        'generated_at': datetime.now().strftime('%d %B %Y, %H:%M'),
        'total_teams': total_teams,
        'total_unmanaged': total_unmanaged,
        'total_departments': total_departments,
    }
