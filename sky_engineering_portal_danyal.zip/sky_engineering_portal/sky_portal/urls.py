"""
Top-level URL routing for the Sky Engineering Portal.

In the group project this file will already exist - the only line that
matters from here is the include for 'reports.urls'.
"""

from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect


urlpatterns = [
    path('admin/', admin.site.urls),
    path('reports/', include('reports.urls')),
    path('', lambda request: redirect('reports:index')),
]
